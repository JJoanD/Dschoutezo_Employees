export interface Employee{
    id: number | undefined,
    firstName : string,
    lastName : string,
    gender : String,
    birthDate : string,
    hireDate : string
}